###### Assumptions:
<li> Code written strictly keeping in consideration that we are not allowed to use external libraries or data structures. e.g. nio packages, primitive base collections (trove, fastutils etc.)
<li> Input file only contains numbers which are represented by <b>int</b> data type. Modifications needed to support long and floating point numbers.</li>
<li> Input file is well formed, valid. If this is not true, program will terminates with error message.</li>

###### Implementation Details:
[TriangleMaxTotalSumMain](src/main/java/com/abc/TriangleMaxTotalSumMain.java): Entry point for the program. Takes hardcoded filename and look it up on classpath.<br /><br />
[TrivialFileParserImpl](src/main/java/com/abc/TrivialFileParserImpl.java): BufferedReader based simple file reader/parser. This can be replaced with NIO based more efficient reader if need arise.
Parser also assumes that input consist of numbers represented by int data type. We can extend this to support floating point or long if need arise by help of generics.<br /><br />
This can also be achieved using stream based API like Files.lines() and using primitive based array e.g.int[][]<br /><br />
[MaxTotalSumCalculatorImpl](src/main/java/com/abc/MaxTotalSumCalculatorImpl.java): Calculates total max path sum for given input triangle with O(n * m) = O(n * n) where m = n = total # of rows/columns in input triangle.
This implementation also does calculation in-place with O(1) space and as a side-effect triangle passed as input parameter is not useful afterwards.

