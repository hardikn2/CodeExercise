package com.abc;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

class TrivialFileParserImplTest {

    @Test
    void readAndParseTriangleSampleFile() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("triangle_sample.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(4, actual.size());
        ArrayList<Integer> expected = new ArrayList<>(Arrays.asList(8,5,9,3));
        Assertions.assertArrayEquals(expected.toArray(), actual.get(3).toArray());
    }

    @Test
    void readAndParseTriangleEmptyFile() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("triangle_empty.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(0, actual.size());
    }

    @Test
    void readAndParseTriangleGibberishInput() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("triangle_gibberishinput.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(0, actual.size());
    }

    @Test
    void readAndParseTriangleWhiteSpaces() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("triangle_whitespaces.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(4, actual.size());
        ArrayList<Integer> expected = new ArrayList<>(Arrays.asList(2, 4, 6));
        Assertions.assertArrayEquals(expected.toArray(), actual.get(2).toArray());

    }

    @Test
    void readAndParseTriangleBigNumbers() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("triangle_bignumber.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(0, actual.size());
    }

    @Test
    void readAndParseNonTriangle() throws URISyntaxException {
        Path path = Paths.get(ClassLoader.getSystemResource("non_triangle.txt").toURI());
        ArrayList<ArrayList<Integer>> actual = new TrivialFileParserImpl().readAndParseTriangle(path);
        Assertions.assertEquals(0, actual.size());
    }
}