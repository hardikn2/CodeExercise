package com.abc;


import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MaxTotalSumCalculatorImplTest {

    @Test
    void calculateMaxTotalSumHappyPath() {
        ArrayList<Integer> row1 = new ArrayList<>(Arrays.asList(3));
        ArrayList<Integer> row2 = new ArrayList<>(Arrays.asList(7, 4));
        ArrayList<Integer> row3 = new ArrayList<>(Arrays.asList(2, 4, 6));
        ArrayList<Integer> row4 = new ArrayList<>(Arrays.asList(8, 5, 9, 3));
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>(Arrays.asList(row1, row2, row3, row4));

        assertEquals(23, new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(triangle));
    }

    @Test
    void calculateMaxTotalSumOverflow() {
        ArrayList<Integer> row1 = new ArrayList<>(Arrays.asList(3));
        ArrayList<Integer> row2 = new ArrayList<>(Arrays.asList(7, Integer.MAX_VALUE - 3));
        ArrayList<Integer> row3 = new ArrayList<>(Arrays.asList(2, 4, 5));
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>(Arrays.asList(row1, row2, row3));

        assertThrows(ArithmeticException.class, () -> new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(triangle));
    }

    @Test
    void calculateMaxTotalSumNegativeInput() {
        ArrayList<Integer> row1 = new ArrayList<>(Arrays.asList(-3));
        ArrayList<Integer> row2 = new ArrayList<>(Arrays.asList(-7, -4));
        ArrayList<Integer> row3 = new ArrayList<>(Arrays.asList(-2, -4, -6));
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>(Arrays.asList(row1, row2, row3));

        assertEquals(-11, new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(triangle));
    }

    @Test
    void calculateMaxTotalSumOneElement() {
        ArrayList<Integer> row1 = new ArrayList<>(Arrays.asList(3));
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>(Arrays.asList(row1));
        assertEquals(3, new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(triangle));
    }

    @Test
    void calculateMaxTotalSumNullInput() {
        assertThrows(IllegalArgumentException.class,
                () -> new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(new ArrayList<>()));
    }

    @Test
    void calculateMaxTotalSumEmptyRowInput() {
        ArrayList<Integer> row1 = new ArrayList<>();
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>(Arrays.asList(row1));
        assertThrows(IllegalArgumentException.class, () -> new MaxTotalSumCalculatorImpl().calculateMaxTotalSum(triangle));
    }


}