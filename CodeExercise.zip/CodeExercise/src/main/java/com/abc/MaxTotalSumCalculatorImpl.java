package com.abc;

import java.util.ArrayList;
import java.util.List;

public class MaxTotalSumCalculatorImpl implements MaxTotalSumCalculator {

    /**
     * Calculate max total sum for input triangle.
     * <p>
     * Time Complexity: O(n*n) where n is total number of rows/columns
     * <p>
     * Since all calculation are done <B>in-space</B> caller of method <B>shouldn't</B> use input triangle
     * after execution returns back to caller
     * <p>
     * Space Complexity: O(1)
     *
     * @param input triangle represented as ArrayList<ArrayList<Integer>> to take advantage of constant lookup time
     * @return total max sum for given triangle
     * @throws ArithmeticException      case when int overflow happens
     * @throws IllegalArgumentException when input is invalid e.g. null, empty
     */
    public int calculateMaxTotalSum(final ArrayList<ArrayList<Integer>> input) {
        if (input == null || input.size() == 0 || input.get(0) == null || input.get(0).size() == 0) {
            throw new IllegalArgumentException("Input triangle is not valid");
        }
        int totalRows = input.size();
        for (int row = totalRows - 2; row >= 0; row--) {
            List<Integer> currentRow = input.get(row);
            List<Integer> nextRow = input.get(row + 1);
            for (int col = 0; col <= row; col++) {
                Integer currentMaxSum = Math.max(nextRow.get(col), nextRow.get(col + 1));
                //checking for int overflow.
                //in case of overflow will throw ArithmeticException
                currentRow.set(col, Math.addExact(currentRow.get(col), currentMaxSum));
            }
        }
        return input.get(0).get(0);
    }
}
