package com.abc;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class TriangleMaxTotalSumMain {

    public static void main(String[] args) {

        //replace below with appropriate file/full path
        String fileName = "triangle_sample.txt";
        Path userFile;
        try {
            userFile = Paths.get(ClassLoader.getSystemResource(fileName).toURI());
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error occurred while locating input file: " + fileName);
            return;
        }

        new TriangleMaxTotalSumMain().readFileAndCalculateMaxTotalSum(userFile);

    }

    public void readFileAndCalculateMaxTotalSum(final Path inputFile) {
        //Below parser can be replaced with NIO/channel or other impl based on user needs
        FileParser fileParser = new TrivialFileParserImpl();
        ArrayList<ArrayList<Integer>> triangle = fileParser.readAndParseTriangle(inputFile);
        if (!triangle.isEmpty()) {
            findAndPrintTotalMaxSum(triangle);
        } else {
            System.err.println("Error occurred while reading/parsing input file: " + inputFile);
        }
    }

    private void findAndPrintTotalMaxSum(final ArrayList<ArrayList<Integer>> input) {
        try {
            //below calculator can be replaced with implementation which require extra storage and doesn't
            //modify input ArrayList thus causing no any side affects
            MaxTotalSumCalculator calculator = new MaxTotalSumCalculatorImpl();
            int maxPathSum = calculator.calculateMaxTotalSum(input);
            System.out.println("Maximum total sum: " + maxPathSum);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error occurred during calculation of total max sum");
        }
    }

}
