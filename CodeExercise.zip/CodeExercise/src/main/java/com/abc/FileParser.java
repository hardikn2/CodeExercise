package com.abc;

import java.nio.file.Path;
import java.util.ArrayList;

public interface FileParser {
    ArrayList<ArrayList<Integer>> readAndParseTriangle(final Path path);
}