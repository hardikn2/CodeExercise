package com.abc;

import java.util.ArrayList;

public interface MaxTotalSumCalculator {
    int calculateMaxTotalSum(final ArrayList<ArrayList<Integer>> input);
}
