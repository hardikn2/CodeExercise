package com.abc;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.stream.Stream;

/**
 * Basic Utility using jdk BufferedReader classes
 */
public class TrivialFileParserImpl implements FileParser {

    /**
     * Read and parse triangle supplied in input file.
     * <p>
     * This can also be implemented using java 8 stream base API like Files.lines() and simply using primitive based
     * array as storage e.g. int[][]
     *
     * @param path path of input file representing triangle
     * @return triangle represented as ArrayList<ArrayList<Integer>>, empty ArrayList when input file
     * is invalid or non-parsable. Choice of concrete ArrayList instead of List as return type is intentional
     * as restriction to not use other implementation like LinkedList and get advantage of constant random-access lookup
     */
    public ArrayList<ArrayList<Integer>> readAndParseTriangle(final Path path) {
        //we don't have total numbers of rows known and using LinkedList will increase time-complexity during
        //random lookup. Using ArrayList solves the constant random access problem. However, it will end up using
        //extra space or keep re-sizing based on size of file. Also, due to constraint of not able to use primitive type in
        //collection we still be using more memory than pure primitive(int) based solution
        ArrayList<ArrayList<Integer>> triangle = new ArrayList<>();

        //try (Stream<String> stream = Files.lines(path)) {
        //}

        try (BufferedReader bufferedReader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String currentFullLine;
            int currentLineIndex = 1;
            while ((currentFullLine = bufferedReader.readLine()) != null) {
                //we don't want to keep re-sizing the array as we see more elements
                //we already know total elements in given row because input file is triangle
                ArrayList<Integer> currentLine = new ArrayList<>(currentLineIndex);
                if (currentFullLine != null && !currentFullLine.isBlank()) {
                    String[] line = currentFullLine.trim().split("\\s+");

                    if (line.length != currentLineIndex) {
                        //given input is not triangle
                        throw new IllegalArgumentException("Invalid line format at line " + currentLineIndex);
                    }

                    for (int i = 0; i < line.length; i++) {
                        currentLine.add(Integer.valueOf(line[i]));
                    }
                    triangle.add(currentLine);
                }
                currentLineIndex++;
            }
        } catch (Exception ex) {
            //reset the triangle
            triangle = new ArrayList<>();
            System.out.println("Error occurred while reading/parsing file");
            ex.printStackTrace();
        }
        return triangle;
    }
}
